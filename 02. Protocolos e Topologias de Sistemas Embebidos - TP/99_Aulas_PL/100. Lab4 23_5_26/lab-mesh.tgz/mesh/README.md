Mesh demo

Layer 3 Mesh for Dynamic networks

A configuração estática usando rotas /128 funcionou bem.

A configuração com OSPFv3 foi abandonada porque as formação das adjacencias fica instável.

A configuração com ripngd e split-horizon só cria as rotas para vizinhos. A propagação de rotas para destinos remotos é bloqueada pelo split-horion uma vez tudo usa a mesma interface.

A configuração com ripngd mas com split-horizon desligado permite propagar todas as rotas, mas os next-hops dos destinos remotos ficam errados porque são propagados e reutilizados. Este é o comportamento do ripngd, apesar de não ser alinhado com Belman-Ford. O quagga/ripngd não permite desligar o split-horizon. Foi aplicado o frr/ripngd, disponível em kathara/frr ou instalada em frr-isep, com o mesmo resultado.

ToDo: usar versão alaterada do FRR.

